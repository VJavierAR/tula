from odoo import models
import logging, ast
import datetime, time
import xlsxwriter
import pytz
_logger = logging.getLogger(__name__)
months = ["Unknown","January","Febuary","March","April","May","June","July","August","September","October","November","December"]
class MovimientosXlsx(models.AbstractModel):
    _name = 'report.libro.compras'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, account):
        i=4
        d=[]
        merge_format = workbook.add_format({'bold': 1,'border': 1,'align': 'center','valign': 'vcenter','fg_color': 'blue'})
        report_name = 'Libro de Compras'
        bold = workbook.add_format({'bold': True})
        money = workbook.add_format({'num_format': '$#,##0'})
        number = workbook.add_format({'num_format': '0.00'})
        sheet = workbook.add_worksheet('Libro de Compras')
        sheet.merge_range('A1:P1', 'Libro de Compras', merge_format)
        sheet.write(1, 0, self.env.user.company_id.name, bold)
        sheet.write(1, 1,'NIT: ' +str(self.env.user.company_id.vat), bold)
        sheet.write(2, 0,'MES: ' +str(months[datetime.datetime.now().month]), bold)
        sheet.write(2, 1,'AÑO: ' +str(datetime.datetime.now().year), bold)
        for obj in account:
            sheet.write(i, 0, str(i-3), bold)
            sheet.write(i, 1, obj.date.strftime("%Y/%m/%d"), bold)
            sheet.write(i, 2, obj.invoice_doc_serie, bold)
            sheet.write(i, 3, obj.invoice_doc_number, bold)
            sheet.write(i, 4, obj.partner_id.vat, bold)
            sheet.write(i, 5, obj.partner_id.name, bold)
            sheet.write(i, 6, obj.amount_untaxed if(obj.tipo=='1') else 0, number)
            sheet.write(i, 7, obj.amount_untaxed if(obj.tipo=='2') else 0, number)
            sheet.write(i, 8, obj.amount_untaxed if(obj.tipo=='3') else 0, number)
            sheet.write(i, 9, obj.amount_untaxed if(obj.tipo=='4') else 0, number)
            sheet.write(i, 10, obj.amount_untaxed if(obj.tipo=='5') else 0, number)
            iva=obj.line_ids.filtered(lambda x:x.account_id.code=='112101')
            idp=obj.line_ids.filtered(lambda x:x.account_id.code=='531031' and x.name in ['IDP R','IDP S'])
            sheet.write(i, 11,iva[0].debit if(len(iva)>0) else 0, number)
            sheet.write(i, 12,idp[0].debit if(len(idp)>0) else 0, number)
            sheet.write(i, 13, obj.amount_untaxed, number)
            sheet.write(i, 14, obj.amount_total, )
            sheet.write(i, 15, obj.ref, bold)
            i=i+1
        sheet.add_table('A4:P'+str(i),{'style': 'Table Style Medium 9','columns': [{'header': '#'},{'header': 'Fecha'},{'header': 'Serie'},{'header':'Numero'},{'header': 'NIT/CED'},{'header': 'Nombre del Proveedor'},{'header': 'Combustible'},{'header': 'Compras'},{'header': 'Pequeño/Cont'},{'header': 'Servicios'},{'header': 'Import'},{'header': 'IVA'},{'header': 'IDP'},{'header': 'Total'},{'header': 'Base'},{'header': 'Concepto'}]})